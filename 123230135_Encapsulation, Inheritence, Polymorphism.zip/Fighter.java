package main;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author IDEAPAD
 */
public class Fighter extends Hero implements Data{
    public Fighter(String nama, int rilis){
        super(nama,rilis);
    }
    @Override
    public void info(){
        System.out.println("nama = " + nama + "\nTahun rilis = " + rilis);
    }
    @Override
    public void keahlian(){
        System.out.println("keahlian = Bertarung jarak dekat");
    }
    @Override
    public void spesialskill(){
        System.out.println("spesial skill = Pukulan keras");
    }
    @Override
    public void attack(){
        System.out.println("attack = 750");
    }
    @Override
    public void defend(){
        System.out.println("defend = 500");
    }
    @Override
    public void skill(){
        System.out.println("skill = 250");
    }
}
