/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author IDEAPAD
 */
public abstract class Hero {
    protected String nama;
    protected int rilis;
    
    public Hero(String nama, int rilis){
        this.nama = nama;
        this.rilis = rilis;
    }
    
    public abstract void keahlian();
    public abstract void spesialskill();
}
