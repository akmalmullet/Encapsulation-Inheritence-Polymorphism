/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice = 0;
        
        try{
            System.out.print("masukan nama fighter :");
            String namaFighter = sc.nextLine();
            System.out.print("Masukan tahun rilis fighter :");
            int rilisFighter = sc.nextInt();
            sc.nextLine();
            
            System.out.print("Masukan nama Mage :");
            String namaMage = sc.nextLine();
            System.out.print("Masukan tahun rilis Mage :");
            int rilisMage = sc.nextInt();
            sc.nextLine();
            
            System.out.print("Masukan nama Tank :");
            String namaTank = sc.nextLine();
            System.out.print("Masukan tahun rilis Tank :");
            int rilisTank = sc.nextInt();
            sc.nextLine();
            
           
            Fighter fighter = new Fighter(namaFighter, rilisFighter);
            Mage mage = new Mage(namaMage, rilisMage);
            Tank tank = new Tank(namaTank, rilisTank);
            
            do{
                System.out.println("\n======== Menu Hero ========");
                System.out.println("1. Fighter");
                System.out.println("2. Mage");
                System.out.println("3. Tank");
                System.out.println("4. Keluar");
                System.out.println("Masukan angka untuk memilih menu :");
                
            try{
                choice = sc.nextInt();
                sc.nextLine();
                
                switch (choice){
                    case 1:
                        System.out.println("DATA HERO - FIGHTER");
                        fighter.info();
                        fighter.keahlian();
                        fighter.spesialskill();
                        fighter.attack();
                        fighter.defend();
                        fighter.skill();
                        break;
                    case 2:
                        System.out.println("DATA HERO - MAGE");
                        mage.info();
                        mage.keahlian();
                        mage.spesialskill();
                        mage.attack();
                        mage.defend();
                        mage.skill();
                        break;
                    case 3:
                        System.out.println("DATA HERO - TANK");
                        tank.info();
                        tank.keahlian();
                        tank.spesialskill();
                        tank.attack();
                        tank.defend();
                        tank.skill();
                        break;
                    case 4:
                        System.out.println("TERIMAKASIH! ");
                        break;
                    default:
                        System.out.println("pilihan tidak valid");
                }
            } catch(InputMismatchException e){
                System.out.println("MASUKAN DATA YANG VALID !!");
                sc.nextLine();
            }
            } while(choice!=4);
        } catch(InputMismatchException e){
                System.out.println("MASUKAN DATA YANG VALID !!");
            }finally {
            sc.close();
        }
    
}
}
