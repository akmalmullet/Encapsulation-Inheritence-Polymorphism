/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author IDEAPAD
 */
public class Tank extends Hero implements Data{
    public Tank(String nama, int rilis){
        super(nama,rilis);
    }
    @Override
    public void info(){
        System.out.println("nama = " + nama + "\nTahun rilis = " + rilis);
    }
    @Override
    public void keahlian(){
        System.out.println("keahlian = Memiliki darah tebal");
    }
    @Override
    public void spesialskill(){
        System.out.println("spesial skill = Memiliki 2 nyawa");
    }
    @Override
    public void attack(){
        System.out.println("attack = 250");
    }
    @Override
    public void defend(){
        System.out.println("defend = 750");
    }
    @Override
    public void skill(){
        System.out.println("skill = 500");
    }
}
