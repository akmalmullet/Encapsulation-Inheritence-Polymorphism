/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author IDEAPAD
 */
public class Mage extends Hero implements Data{
    public Mage(String nama, int rilis){
        super(nama,rilis);
    }
    @Override
    public void info(){
        System.out.println("nama = " + nama + "\nTahun rilis = " + rilis);
    }
    @Override
    public void keahlian(){
        System.out.println("keahlian = Bertarung jarak jauh");
    }
    @Override
    public void spesialskill(){
        System.out.println("spesial skill = shield");
    }
    @Override
    public void attack(){
        System.out.println("attack = 500");
    }
    @Override
    public void defend(){
        System.out.println("defend = 250");
    }
    @Override
    public void skill(){
        System.out.println("skill = 750");
    }
}
